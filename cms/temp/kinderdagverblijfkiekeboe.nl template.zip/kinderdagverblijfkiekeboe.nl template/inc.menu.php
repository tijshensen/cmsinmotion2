<ul class="nav navbar-nav">
	<menu type="head">
		<li class="[[currentindicator]]"><a href="[[href]]">[[title]]</a></li>
	</menu>
	<menu type="head-with-dropdown">
		<li class="dropdown">
			<a href="#" class="dropdown-toggle" data-toggle="dropdown">[[title]] <span class="caret"></span></a>
			<ul class="dropdown-menu" role="menu">
				<menuitem type="dropdown">
					<li><a href="[[href]]">[[title]]</a></li>
				</menuitem>
			</ul>
		</li>
	</menu>
</ul>