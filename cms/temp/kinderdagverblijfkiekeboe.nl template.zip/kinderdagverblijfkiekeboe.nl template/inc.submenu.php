<ul>
	<menuitem type="submenu">
		<li class="[[currentindicator]]"><a href="[[href]]">[[title]]</a></li>
	</menuitem>
</ul>