
			
			jQuery(window).load(function() {
				jQuery('div#slider').nivoSlider({
				pauseTime:5000,
				animspeed:500,
				directionNav:true,
				controlNav:false,
				pauseOnHover:false,
				captionOpacity:1,
				afterLoad: function(){$('#slider .nivo-caption').css("left","0")},    
				beforeChange: function(){$('#slider .nivo-caption').css("left","-100%")},
				afterChange: function(){$('#slider .nivo-caption').css("left","0")}
				});
			});
			
			jQuery(function() {
                jQuery("#toTop").scrollToTop(1000);
            });