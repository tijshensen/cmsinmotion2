<form class="navbar-form navbar-right hidden-md " role="search">
	<div class="form-group">
	  <input type="text" class="form-control" placeholder="">
	</div>
	<button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
</form>