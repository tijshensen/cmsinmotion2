<ul>
	<li><a href="">Prijzen en openingstijden</a></li>
	<li class="current"><a href="">Pedagogisch beleid</a></li>
	<li><a href="">Eten, slapen & zindelijkheid</a></li>
</ul>